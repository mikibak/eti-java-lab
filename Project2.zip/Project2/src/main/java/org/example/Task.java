package org.example;

public interface Task {

    public Object execute() throws InterruptedException;
    public Object resultHash();

}
